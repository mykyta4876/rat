#pragma once
#include <vector>
class SERVER;
extern std::vector<SERVER*> client_array;
extern std::vector<int> client_ids;
extern int id_var;
extern int current_client;
