#pragma once
void display_admin_help();
void display_client_help();
void show_clients();