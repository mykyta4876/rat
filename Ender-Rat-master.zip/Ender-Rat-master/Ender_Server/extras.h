#pragma once
#include <iostream>
#include <string>
using namespace std;

void show_update(string);
void show_update(string, int);
void show_update(string, int, string);
void show_error(string);
void show_shell();
bool check_current_client_id(int);
