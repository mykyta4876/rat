# Ender-Rat
Remote Administration Tool For Windows

## Under Development

I started this as one of my college projects and it is in very early stage of development right now. I am working on this whenever I have free time trying to improve the old code as well as adding new features. It needs alot of work as i have written this from scratch and will take a lot of time to perfect it. 

This Project was solely created for Educational Purposes and I won't add any features which have any potential of harming anyone. The keylogger fuctionality will be limited in upcoming weeks.

### Professional Looking Readme Underway.......................
