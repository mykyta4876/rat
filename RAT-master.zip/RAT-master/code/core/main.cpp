#include "System.h"

int main() { // For the test building
    System sys(nullptr);
    std::cout << "Test building...";
}