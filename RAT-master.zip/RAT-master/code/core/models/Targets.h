//
// Created by al_sah on 30.05.21.
//

#ifndef CORE_TARGETS_H
#define CORE_TARGETS_H

enum targets_enum{
    bot = 1,
    server = 2,
    control = 3
};

#endif //CORE_TARGETS_H
