//
// Created by al_sah on 18.07.21.
//

#include "../ApplicationContext.h"

ApplicationContext::ApplicationContext(std::string moduleId, std::string version) : AbstractApplicationContext(
        moduleId, version) {}
