#ifndef RESOURCES_H
#define RESOURCES_H

struct botInfo {
    QString cameraPhotoPath;
    QString screenshotPath;
};

#endif // RESOURCES_H
