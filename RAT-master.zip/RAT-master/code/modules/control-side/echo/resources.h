#ifndef RESOURCES_H
#define RESOURCES_H

struct botInfo {
    QString messages;
};

#endif // RESOURCES_H
