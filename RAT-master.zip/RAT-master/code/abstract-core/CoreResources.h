//
// Created by al_sah on 17.07.21.
//

#ifndef ABSTRACT_CORE_RESOURCES
#define ABSTRACT_CORE_RESOURCES

#include "GlobalResources.h"
#include "CoreConfiguration.h"


#include "models/ParsedTextMessage.h"
#include "models/TaskInfo.h"

typedef size_t Size;



#endif //ABSTRACT_CORE_RESOURCES
