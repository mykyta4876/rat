#ifndef BASIC_CONFIGURATION
#define BASIC_CONFIGURATION


#include <Module.h>
#include <string>


#endif //BASIC_CONFIGURATION