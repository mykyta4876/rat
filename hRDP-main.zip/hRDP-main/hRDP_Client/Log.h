#pragma once
namespace Log {

	void SaveLog(wchar_t* txt);
}