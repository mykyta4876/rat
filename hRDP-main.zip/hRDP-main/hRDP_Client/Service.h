#pragma once
#include"Globals.h"
namespace Service {
	void serviceManage(wchar_t* service, BOOL start);
}