#pragma once
#include<WinSock2.h>
#include<Windows.h>
#include<iostream>
extern const wchar_t* dllService;