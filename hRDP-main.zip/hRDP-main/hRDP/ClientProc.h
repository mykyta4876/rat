#pragma once

namespace ClientProc {

	void spawnProcClient(SOCKET* s);
	void ClientStart(SOCKET client);
}