# hRDP
Hidden RDP
![Capture](https://github.com/user-attachments/assets/fb864b7b-91da-48c6-90ec-a30e791c6807)

![Capture2](https://github.com/user-attachments/assets/d4feb924-8236-4e85-a805-68b8a760358c)
# Tested On :  
windows 11 pro  
windows 11 home  
windows 7 pro  
windows 10 pro x64  
windows 10 home x32  
  
not all windows versions are supported !  
