#pragma once

void autostart();
