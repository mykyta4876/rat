#pragma once

void startup(int argc, char** argv);
