#pragma once
#include <set>

namespace diskchanges {
	std::set<char> GetDiskList();
	void Diskchanges();
}
