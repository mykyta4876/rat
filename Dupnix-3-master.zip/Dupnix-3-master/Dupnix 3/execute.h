#pragma once
#include <string>

#include "parse.h"

namespace execute {
	void execute(parse::ParsedMessage PM);
}
