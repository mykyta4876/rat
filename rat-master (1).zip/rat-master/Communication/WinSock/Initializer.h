#pragma once

class Initializer
{
public:
	Initializer();
	~Initializer();
};
