#include "Entrypoint.h"


int main()
{
	Entrypoint();
}