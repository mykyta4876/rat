﻿namespace Server.Interop;

public class Dependencies
{
    public const string CommunicationDll = "Communication.dll";
    public const string ServerDll = "Server.dll";
}