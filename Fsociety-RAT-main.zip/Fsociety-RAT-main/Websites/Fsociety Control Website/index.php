<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
  </head>
  <body>

    <div class="big">
      <h1>My First Website</h1>
    </div>

      <div class="LoginBox">
        <div class="title">
          <h1>Login</h1>
        </div>
        
        <div class="text">
          <form action="#" method="post">
            <label>Username:</label><br>
            <input type="password" name="username" placeholder="Username:"><br>
            <label>Password:</label><br>
            <input type="password" name="pass" placeholder="Password:"><br>
            <input type="submit" name="login" value="Login"><br>
          </form>
          <p>* No database yet ): SOON</p>
        </div>
        
      </div>
  </body>
</html>