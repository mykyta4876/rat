<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My first Website</title>
</head>
<body>
    
    <div class="soon_title">
        <h1>SOON (:</h1>
    </div>


</body>
</html>

<style>

    *
    {
        padding: 0;
        margin: 0;
    }

    body
    {
        background-color: lightgray;
    }

    .soon_title
    {
        width: 100%;
        height: auto;
        text-align: center;
        margin-top: 200px;
        font-family: 'Courier New', Courier, monospace;
        font-size: 100px;
    }

</style>